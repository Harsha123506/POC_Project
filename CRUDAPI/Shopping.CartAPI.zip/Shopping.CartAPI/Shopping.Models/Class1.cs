﻿namespace Shopping.Models
{
    public class Class1
    {

    }
}
