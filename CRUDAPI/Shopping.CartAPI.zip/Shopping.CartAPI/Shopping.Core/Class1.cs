﻿namespace Shopping.Core
{
    public class Class1
    {

    }
}
